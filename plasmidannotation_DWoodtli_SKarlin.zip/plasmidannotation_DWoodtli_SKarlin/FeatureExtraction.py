from collections import defaultdict
from Bio import SeqIO
from Bio.SeqFeature import SeqFeature, FeatureLocation
import json


class FeatureExtraction:

    def createFinalJsonFile(self, vectorfile, jsonfilename):
        """
        This Function (class) reads an an genbank file with annotated plasmids and is filtering the annotations of the
        given plasmids.
        At the end it creates a final training file in JSON format
        :param vectorfile: filename of genbank file containing all known vector annotations
        :param jsonfilename: final json file containing all filtered and counted sequences
        """
        def deleteShortSequences(record_list):
            """
            Function to filter plasmid with a sequence length > 1500 bases
            :param record_list: a list of records of the read genbank file
            :return: filtered_list: contains als records with a sequences length > 1500 bases
            """
            global amtSmallPlasmids
            amtSmallPlasmids = 0
            filtered_list = []
            for record in record_list:
                if len(record.seq) > 1500:
                    filtered_list.append(record)
                else:
                    amtSmallPlasmids += 1
            return filtered_list

        records = list(SeqIO.parse(vectorfile, "genbank"))

        records_filtered = deleteShortSequences(records)

        list_of_feature_types = ['promoter', 'oriT', 'rep_origin', 'primer_bind', 'terminator', 'misc_signal',
                                 'misc_recomb',
                                 'LTR', 'enhancer', '-35_signal', '-10_signal', 'RBS', 'polyA_signal',
                                 'sig_peptide', 'CDS',
                                 'protein_bind', 'misc_binding', 'mobile_element', 'mRNA', 'tRNA', 'rRNA']

        list_of_feature_type_for_notes = list_of_feature_types[:9]

        list_of_feature_types_for_notesAndGene = list_of_feature_types[9:14]

        list_of_feature_types_for_geneAndProduct = list_of_feature_types[14]

        list_of_feature_types_for_noteAndBoundMoiety = list_of_feature_types[15:17]

        list_of_feature_types_for_noteAndMobileElementType = list_of_feature_types[17]

        list_of_feature_type_for_gene = list_of_feature_types[18]

        list_of_feature_type_for_product = list_of_feature_types[19:]

        # Create Dictionary and count same entries----------------------------------------------------------------------
        dic = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: int())))

        SIZE_SEQUENCE_TO_FILTER = 8

        AMOUNT_COUNTS_TO_DELETE = 3

        amtSameID = 0
        IDs = []
        doubleIDs = []
        amtShortSequences = 0
        amtTotalSequences = 0

        SEPERATOR = ' | '

        print "Creating new dictionary of training genbank entries..."

        for record in records_filtered:

            if record.id in IDs:
                doubleIDs.append(record.id)
                amtSameID += 1
            for feature in record.features:
                if feature.type in list_of_feature_types:
                    start = feature.location.start
                    end = feature.location.end
                    lengthSequence = abs(end - start)
                    amtTotalSequences += 1
                    if lengthSequence >= SIZE_SEQUENCE_TO_FILTER:
                        sequence = feature.extract(record.seq)
                        amtShortSequences += 1
                        stringName = ''
                        for qualifier in feature.qualifiers.keys():
                            if feature.type in list_of_feature_type_for_notes and qualifier == 'note':
                                for element in feature.qualifiers[qualifier]:
                                    stringName = qualifier + ': ' + element
                            if feature.type in list_of_feature_types_for_notesAndGene and (
                                            qualifier == 'note' or qualifier == 'gene'):
                                stringName += qualifier
                                for element in feature.qualifiers[qualifier]:
                                    stringName += ': ' + element + SEPERATOR
                            if feature.type in list_of_feature_types_for_geneAndProduct and (
                                            qualifier == 'gene' or qualifier == 'product'):
                                stringName += qualifier
                                for element in feature.qualifiers[qualifier]:
                                    stringName += ': ' + element + SEPERATOR
                            if feature.type in list_of_feature_types_for_noteAndBoundMoiety and (
                                            qualifier == 'note' or qualifier == 'bound_moiety'):
                                stringName += qualifier
                                for element in feature.qualifiers[qualifier]:
                                    stringName += ': ' + element + SEPERATOR
                            if feature.type in list_of_feature_types_for_noteAndMobileElementType and (
                                            qualifier == 'note' or qualifier == 'mobile element featuretype'):
                                stringName += qualifier
                                for element in feature.qualifiers[qualifier]:
                                    stringName += ': ' + element + SEPERATOR
                            if feature.type in list_of_feature_type_for_gene and qualifier == "gene":
                                for element in feature.qualifiers[qualifier]:
                                    stringName = qualifier + ': ' + element
                            if feature.type in list_of_feature_type_for_product and qualifier == "product":
                                for element in feature.qualifiers[qualifier]:
                                    stringName = qualifier + ': ' + element
                            if stringName != '':
                                dic[str(sequence)][feature.type][stringName] += 1

                IDs.append(record.id)

        print "Dictionary created:"
        print "--> Obtained %d sequences with length > 8 out of %d sequences; deleted %d sequences" % (
            amtShortSequences, amtTotalSequences, amtTotalSequences - amtShortSequences)

        print"------------------------------------------------------------------------------------------------------"
        print"Check size of manipulated lists and dicts: "
        print""
        print " --> Length with all Sequences: %d" % len(records)
        print " --> amount of sequences < 1500 bases: %d" % amtSmallPlasmids
        print" --> Length with filtered sequences > 1500 bases: %d; diffrence: %d " % (
            len(records_filtered), len(records) - len(records_filtered))
        print " --> amount of records with same ID: %d; ID of duplicate records: %s" % (amtSameID, doubleIDs)


        lengthDicAfterCreation = len(dic)

        # Sum of all features before deletion------------------------------------------------------------------------
        total = 0
        totalcounts = 0
        for sequence in dic.keys():
            for featuretype in dic[sequence]:
                for qualifier in dic[sequence][featuretype]:
                    total += 1
                    totalcounts += dic[sequence][featuretype][qualifier]

        # Delete counts <=3 -------------------------------------------------------------------------------------------
        for sequence in dic.keys():
            for featuretype in dic[sequence].keys():
                for qualifier in dic[sequence][featuretype].keys():
                    if dic[sequence][featuretype][qualifier] <= AMOUNT_COUNTS_TO_DELETE:
                        del dic[sequence][featuretype][qualifier]

        # Delete features types with no qualifier----------------------------------------------------------------------
        for sequence in dic.keys():
            for featuretype, typevalue in zip(dic[sequence].keys(), dic[sequence].values()):
                if len(typevalue) == 0:
                    del dic[sequence][featuretype]

        # Delete sequences with no feature types----------------------------------------------------------------------
        for sequence in dic.keys():
            if len(dic[sequence]) == 0:
                del dic[sequence]

        # Delete smaller counts of qualifier if more than one are available---------------------------------------------
        for sequence in dic.keys():
            for featuretype in dic[sequence].keys():
                while len(dic[sequence][featuretype]) > 1:
                    value1 = dic[sequence][featuretype].items()[0][1]
                    value2 = dic[sequence][featuretype].items()[1][1]
                    if value1 > value2:
                        key = str(dic[sequence][featuretype].items()[1][0])
                        del dic[sequence][featuretype][key]

                    else:
                        key = str(dic[sequence][featuretype].items()[0][0])
                        del dic[sequence][featuretype][key]
            # after keeping qualifier with max count, there can be still 2 f. types with qualifiers with different counts
            # next loop will identify those and delete the smaller one
            while len(dic[sequence]) > 1:
                featuretypeList = dic[sequence].keys()
                for i in range(0, len(featuretypeList)-1):
                    value1 = dic[sequence][featuretypeList[i]].items()[0][1]
                    value2 = dic[sequence][featuretypeList[i+1]].items()[0][1]
                    if value1 > value2:
                        del dic[sequence][featuretypeList[i+1]]  # deleting the featuretype with less counts in its qualifier
                    else:
                        del dic[sequence][featuretypeList[i]]

        # Write Dic after deletions to file----------------------------------------------------------------------------
        with open(jsonfilename, "w") as delDic_JSON:
            json.dump(dic, delDic_JSON, indent=4, sort_keys=True)

        # Total features after all deletions --------------------------------------------------------------------------
        amtOfFeaturesAfterDeletion = 0
        amtOfFeaturesAfterDeletionCounts = 0
        for sequence in dic:
            for featuretype in dic[sequence]:
                for qualifier in dic[sequence][featuretype]:
                    amtOfFeaturesAfterDeletion += 1
                    amtOfFeaturesAfterDeletionCounts += dic[sequence][featuretype][qualifier]

        lengthDicAfterDeletions = len(dic)
        print ""
        print "------------------------------------------------------------------------------------------------------"
        print "Results of feature extraction:"
        print ""
        print "Final amount of sequences after selection: %d out of %d " % (
            lengthDicAfterDeletions, lengthDicAfterCreation)
        print "Final amount of filtered feature qualifiers: (%d features, %d counts) out of (%d features, %d counts)" % (
            amtOfFeaturesAfterDeletion, amtOfFeaturesAfterDeletionCounts, total, totalcounts)
        print "------------------------------------------------------------------------------------------------------"
