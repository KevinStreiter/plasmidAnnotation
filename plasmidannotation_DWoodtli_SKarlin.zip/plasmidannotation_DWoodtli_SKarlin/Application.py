import sys

from Bio import SearchIO
from Bio import Seq
from Bio import SeqRecord
from Bio.Alphabet import IUPAC
from Bio.Blast import NCBIWWW
from Bio.SeqFeature import CompoundLocation
from FeatureExtraction import *
from ReadJsonFile import *

def check_endposition(endposition, testsequence):
    if endposition > len(testsequence) - 1:
        new_endposition = endposition - len(testsequence)
        return new_endposition
    return endposition

def appendFeatures(plasmid_object, start, end, strand, type, qualifier, location_operator):
    if start > end:
        plasmid_object.features.append(SeqFeature(CompoundLocation([FeatureLocation(start, len(plasmid_object.seq)), FeatureLocation(0, end)]),
                                                  type=type, strand=strand,qualifiers=qualifier, location_operator=location_operator))
    else:
        plasmid_object.features.append(SeqFeature(FeatureLocation(start, end), type=type,
                                                  strand=strand,qualifiers=qualifier))

def blast_protein(start, plasmid_object, blasted_strand):
    openf = False
    end_pos = 0
    doubled_plasmid = plasmid_object.seq + plasmid_object.seq

    for i in range(start, len(plasmid_object.seq), 3):
        if openf == False:
            if doubled_plasmid[i:i + 3] == "ATG":
                start_pos = i
                openf = True
        if openf == True:
            if doubled_plasmid[i:i + 3] == "TAG" or doubled_plasmid[i:i + 3] == "TAA" or doubled_plasmid[i:i + 3] == "TGA":
                OUTPUT_BLAST = "OutputFiles/blasts.xml"
                end_pos = i
                end_pos = check_endposition(end_pos, plasmid_object)
                openf = False
                translated_hit = Seq.translate(doubled_plasmid[start_pos:end_pos + 1])
                if len(translated_hit) > 50:
                    print "Found: " + str(start_pos) + " to " + str(end_pos) + " Size " + str(end_pos - start_pos)
                    blasts = NCBIWWW.qblast("blastp", "nr", str(translated_hit), hitlist_size=1,expect=0.0001)
                    blast_output = open(OUTPUT_BLAST, "w+")
                    blast_output.write(blasts.read())
                    blast_output.close()
                    blast_results = SearchIO.read(OUTPUT_BLAST, 'blast-xml')
                    print blast_results
                    print ""
                    if len(blast_results.hits) > 0:
                        description = blast_results[0].description
                        qualifier = {"note": description, "translation": translated_hit}
                        appendFeatures(plasmid_object, start_pos, end_pos, blasted_strand, "CDS", qualifier, 'join')

    return plasmid_object

def main(argv):

    # -------------------------Reading provided sequence file----------------------------------------
    checkSuffixFasta = ".fasta"
    checkSuffixGb = ".gb"

    plasmid_list = []

    if len(argv) == 0:
        msg = "Error: You have to enter a fasta or genbank file "
        sys.exit(msg)

    filename = str(argv[0])

    if argv[0].endswith(checkSuffixFasta):
        input_fasta = SeqIO.parse(filename, "fasta")
        for fastRec in input_fasta:
            fastRec = Seq.Seq(str(fastRec.seq), IUPAC.ambiguous_dna)
            plasmid_list.append(SeqRecord.SeqRecord(fastRec))

    elif argv[0].endswith(checkSuffixGb):
        plasmid_list = list(SeqIO.parse(filename, "genbank"))

    elif not argv[0].endswith(checkSuffixFasta) or not argv[0].endswith(checkSuffixFasta):
        msg = "Error: Your file is not a fasta or genbank file"
        sys.exit(msg)

    # ---------------------Filepath to input and output files--------------------------------------

    # Files for feature extraction from genbankfile:
    VECTOR_FILE = "InputFiles/vectors.gb"
    JSON_FILENAME = "OutputFiles/TrainingFile.json"

    # output genbank file for final annotated plasmid:
    OUTPUT_FILE = "OutputFiles/test.gb"

    # input files for primer and epitope annotations
    COMMON_PRIMER_FILE = "InputFiles/common_primer.mfasta"
    TAG_EPITOPES_FILE = "InputFiles/tags_epitopes.mfasta"

    # --------------------Getting Sequence object List from Member 1-----------------------------

    FeatureExtraction().createFinalJsonFile(VECTOR_FILE, JSON_FILENAME)
    data = ReadJsonFile().createObjects(JSON_FILENAME)
    list_sequence_objects = data.getSequenceObjectList()

    output = open(OUTPUT_FILE, "w+")

    # --------------------Annotate Primer Binding Sites-------------------------------
    print ""
    print "------------------------------------------------------------------------------------------------------"
    print "Annotating primer binding sites..."
    for plasmid in plasmid_list:
        doubled_plasmid = plasmid.seq + plasmid.seq
        for primer in SeqIO.parse(COMMON_PRIMER_FILE, "fasta"):

            search = doubled_plasmid.find(primer.seq[-15:])
            if search > -1:
                start_pos = search
                end_pos = start_pos + 15
                end_pos = check_endposition(end_pos, plasmid)
                qualifier = {"note": primer.id}
                appendFeatures(plasmid, start_pos, end_pos, 1, "primer_bind", qualifier, 'join')

            search = plasmid.seq.reverse_complement().find(primer.seq[-15:])
            if search > -1:
                start_pos = search
                end_pos = start_pos + 15
                end_pos = check_endposition(end_pos, plasmid)
                qualifier = {"note": primer.id}
                appendFeatures(plasmid, start_pos, end_pos, -1, "primer_bind", qualifier, 'join')

        print "Finished annotating primer binding sites"

        # --------------------Annotate Special Translated Features------------------------

        print ""
        print "------------------------------------------------------------------------------------------------------"
        print "Annotating special translated features..."

        plasmid.alphabet = IUPAC
        firststrand_firstframe = ""
        firststrand_secondframe = ""
        firststrand_thirdframe = ""
        secondstrand_firstframe = ""
        secondstrand_secondframe = ""
        secondstrand_thirdframe = ""

        for i in range(0, len(plasmid.seq), 3):
            translated_plasmid = Seq.translate(plasmid.seq[i:i + 3])
            firststrand_firstframe += (str(translated_plasmid))
            translated_reversed_plasmid = Seq.translate(str(plasmid.seq.reverse_complement()[i:i + 3]))
            secondstrand_firstframe += translated_reversed_plasmid
        for i in range(1, len(plasmid.seq), 3):
            translated_plasmid = Seq.translate(plasmid.seq[i:i + 3])
            firststrand_secondframe += (translated_plasmid)
            translated_reversed_plasmid = Seq.translate(str(plasmid.seq.reverse_complement()[i:i + 3]))
            secondstrand_secondframe += translated_reversed_plasmid
        for i in range(2, len(plasmid.seq), 3):
            translated_plasmid = Seq.translate(plasmid.seq[i:i + 3])
            firststrand_thirdframe += (translated_plasmid)
            translated_reversed_plasmid = Seq.translate(str(plasmid.seq.reverse_complement()[i:i + 3]))
            secondstrand_thirdframe += translated_reversed_plasmid

        protein_strands = [Seq.Seq(str(firststrand_firstframe)), Seq.Seq(str(firststrand_secondframe)),
                           Seq.Seq(str(firststrand_thirdframe)), Seq.Seq(str(secondstrand_firstframe)),
                           Seq.Seq(str(secondstrand_secondframe)), Seq.Seq(str(secondstrand_thirdframe))]
        for protein_strand in protein_strands:
            for epitope in SeqIO.parse(TAG_EPITOPES_FILE, "fasta"):
                doubled_protein_strand = protein_strand + protein_strand
                search = doubled_protein_strand.find(epitope.seq)
                if search > -1:
                    start_pos = search*3
                    end_pos = start_pos + len(epitope.seq) * 3
                    end_pos = check_endposition(end_pos, protein_strand)
                    print "Found --> ", epitope.id
                    qualifier = {"note": epitope.id}
                    appendFeatures(plasmid, start_pos, end_pos, 1, "misc_feature", qualifier, 'join')

        print "Finished annotating special translated features"

        # -------------------Getting annotations of sequence object list created by Member1-----------------------------
        print ""
        print "------------------------------------------------------------------------------------------------------"
        print "Annotating features of feature extraction from genbank file..."
        for sequenceObject in list_sequence_objects:
            sequence = sequenceObject.getSequence()
            doubled_plasmid = plasmid.seq + plasmid.seq

            search = doubled_plasmid.find(sequence)
            if search > -1:
                start_pos = search
                end_pos = start_pos + len(sequence)
                end_pos = check_endposition(end_pos, plasmid)
                appendFeatures(plasmid, start_pos, end_pos, 1, sequenceObject.getFeatureType(), sequenceObject.getFeatureQualifierDict(), 'join')

            search = doubled_plasmid.reverse_complement().find(sequence)
            if search > -1:
                start_pos = search
                end_pos = start_pos + len(sequence)
                end_pos = check_endposition(end_pos, plasmid)
                appendFeatures(plasmid, start_pos, end_pos, -1, sequenceObject.getFeatureType(), sequenceObject.getFeatureQualifierDict(), 'join')

        print "Finished annotating features from genbank file"


        # -------------------Annotate Protein Coding Genes-----------------------------------

        print ""
        print "------------------------------------------------------------------------------------------------------"
        print "Running blastp..."
        print "Running blastp on RF 1: "
        plasmid = blast_protein(0, plasmid, 1)
        print""
        print "Running blastp on RF -1: "
        plasmid = blast_protein(0, plasmid.reverse_complement(), -1)
        print ""
        print "Running blastp on RF 2: "
        plasmid = blast_protein(1, plasmid, 1)
        print ""
        print "Running blastp on RF -2: "
        plasmid = blast_protein(1, plasmid.reverse_complement(), -1)
        print""
        print "Running blastp on RF 3: "
        plasmid = blast_protein(2, plasmid, 1)
        print""
        print "Running blastp on RF -3: "
        plasmid = blast_protein(2, plasmid.reverse_complement(), -1)
        print ""
        print "Finished BLAST"

        # -----------Annotate Common Features and write genbank file ---------------------------------------------------
        print ""
        print "------------------------------------------------------------------------------------------------------"
        print "Annotation finished successfully, your annotated genbank file is ready"

        SeqIO.write(plasmid, output, "genbank")
    output.close()

if __name__ == "__main__":
    main(sys.argv[1:])
