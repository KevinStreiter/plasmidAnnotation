
class SequenceCollection:
    """
    Class holds all created sequence objects
    """

    def __init__(self):
        """
        Constructor
        """
        self.objectList = []

    def addSequence(self, sequenceObject):
        """
        Function adding new sequence object to the object list, containing all sequences objects provided by the JSON file
        :param sequenceObject: a sequence object created by a sequence of the provided JSON file
        """
        self.objectList.append(sequenceObject)

    def getSequenceObjectList(self):
        """
        Function to get the object list containing all sequence objects
        :return: object list containing all sequence objects
        """
        return self.objectList

    def getSequenceObject(self, index):
        """
        Function to get a sequence object by its index
        :param index: of the wanted sequence object
        :return: the sequence object at the given index
        """
        return self.objectList[index]

    def getSequenceObjectbySequence(self, sequence):
        """
        Function to get the sequences object by its  sequence
        :param sequence: sequence ot the sequence object
        :return: the sequence object for the given sequence
        """
        for sequenceObject in self.objectList:
            if sequenceObject.getSequence() == sequence:
                return sequenceObject

    def getSequenceObjectIndex(self, sequence):
        """
        Functio to get the index of a sequence object identifed by its sequence
        :param sequence: sequence of the wanted sequence object
        :return: the index of the sequence object identified by its sequence  name
        """
        for i in range(0, len(self.objectList)):
            if self.objectList[i].getSequence() == sequence:
                return i