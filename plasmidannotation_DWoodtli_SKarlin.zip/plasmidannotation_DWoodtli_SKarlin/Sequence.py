class Sequence:
    def __init__(self, sequence, featuretype, featurequalifier):
        """
        Constructor to create a sequence object
        :param sequence: sequence provided by the JSON file containing all sequences and their annotations
        :param featuretype: featuretype belonging to the sequence
        :param featurequalifier: featurequalifier belonging to the sequence and its featuretype
        """
        self.sequence = sequence
        self.featuretype = featuretype
        self.featurequalifier = featurequalifier  # is a Dictionary: key: qualifier; value: the note for the qualifier

    def getSequence(self):
        """
        Function to get the sequence of a sequence object
        :return: sequence (String) of sequences object
        """
        return self.sequence

    def getFeatureType(self):
        """
        Function to get feature.type of sequence object
        :return:  feature.type of sequence object
        """
        return self.featuretype

    def getFeatureQualifierDict(self):
        """
        Function to get feature.qualifier of sequence object
        :return:  feature.qualifier dictionary of sequence object
        """
        return self.featurequalifier
