import json
from twisted.protocols.ftp import FileNotFoundError

from Sequence import *

from SequenceCollection import *

class ReadJsonFile:
    """
    Class reads in a given JSON file and creates the sequences data objects
    """

    def createObjects(self, filename):
        """
        Function to read in the given JSON file to create the sequence objects and collect it in the SequenceCollection
        :param filename: JSON file containing the filtered sequences and their annotations (feature.type and feature.qualifier)
        :return: SeqeunceCollection: a model which contains all created sequence objects
        """
        try:
            with open(filename, 'r') as JSON_file:
                try:
                    data = json.load(JSON_file)
                    sequenceCollection = SequenceCollection()
                    for sequence in data:
                        for featuretype in data[sequence]:
                            for qualifier in data[sequence][featuretype]:
                                if '|' in qualifier:
                                    inRead = qualifier.split('|')
                                    dic = {}
                                    for element in inRead:
                                        if str(element) != ' ':  # if no second qualifier is in inRead after split, there will be an empty string
                                            qualifierEntry = element.split(':')
                                            dic.update({qualifierEntry[0].strip(): qualifierEntry[1].strip()})
                                    sequenceCollection.addSequence(Sequence(sequence, featuretype, dic))

                                else:
                                    qualifierEntry = qualifier.split(':')
                                    qualifierdict = dict({qualifierEntry[0].strip(): qualifierEntry[1].strip()})
                                    sequenceCollection.addSequence(Sequence(sequence, featuretype, qualifierdict))

                    return sequenceCollection

                except ValueError:
                    print "Could not Decode Json File"
                    return None


        except FileNotFoundError:
            print "Could not find the file, please check the filepath"
            return None
